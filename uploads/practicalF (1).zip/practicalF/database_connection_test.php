<?php
require 'database_credentials.php';


$connection = new mysqli(servername, username, password);


if ($connection->connect_error) {

    die("Connection failed: " . $connection->connect_error);
} else {

    echo "Connected successfully";
}

?>