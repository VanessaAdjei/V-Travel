<?php
require __DIR__ ."/database_credentials.php";

    
    $conn = new mysqli(servername,username,password,dbname);
    
    
    if($conn->connect_error){
        die("Connection failed: ".$conn->connect_error);
        echo "Connection failed";
    }
    else {
        $Email = $_POST["u"];
        $Password=$_POST["p"];

        $stmt = $conn -> prepare("select * from signupinfo where Email='$Email' and Password='$Password'");
        $stmt -> bind_param("ss",$Email,$Password);
        

       if($stmt -> execute()){
           header('location: index.php');
       }

        echo $conn->error;
        echo "regristration successful";
        $stmt ->close();
        $conn -> close();
        
    }


?>