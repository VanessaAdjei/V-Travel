<?php
require __DIR__ ."/database_credentials.php";

    
    $conn = new mysqli(servername,username,password,dbname);
    
    
    if($conn->connect_error){
        die("Connection failed: ".$conn->connect_error);
        echo "Connection failed";
    }
    else {
        $stmt = $conn -> prepare("insert into signupinfo(FirstName,LastName,Email,Password)values(?,?,?,?)");
        $stmt -> bind_param("ssss",$FirstName,$LastName,$Email,$Password);

        $FirstName = $_POST['FirstName'];
        $LastName = $_POST['LastName'];
        $Email = $_POST['Email'];
        $Password = $_POST['Password'];

        $stmt -> execute();

        echo $conn->error;
        echo "regristration successful";
        $stmt ->close();
        $conn -> close();
    }




?>