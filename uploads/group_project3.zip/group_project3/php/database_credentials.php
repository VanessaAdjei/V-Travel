<?php 

define ("servername", "localhost");
define ("username", "root");
define ("password", "");
define ("dbname", "gade_central_school");


?>