<?php
require __DIR__ ."/database_connection_test.php";
$data=null;
$ID= "";

$searchresult = [];
       if(isset($_GET['searchbar'])){ 
        $input = $_GET['searchbar'] ;
        $searchresult = array_map("reduceArray", selection($input, $conn));
      } 

    function reduceArray($array) {
        return $array[0];
    }
    function selection($theword, $conn){
        //selects from  a database based on student ID
          $theword =trim($theword);
          $sql2 = mysqli_query($conn, "SELECT concat(p.firstname, ' ', p.lastname) as 'Full Name' from `person` as p where concat(p.firstname, ' ', p.lastname) LIKE '%$theword%'");
          $searchquery=mysqli_fetch_all($sql2);
          echo mysqli_error($conn);  
          return $searchquery; 
    }

    $deleteresult ="";
    if(isset($_POST['Delete'])){
        $theID=$_POST['ID'];
        echo $theID;
      $deleteresult =  delete($theID, $conn);

    }
 
    $theID = "";
    function delete($theID, $conn){
        // deletes from a table in the database 
          $sql2="delete from `students` where `SID`='$theID'";
          $q=mysqli_query($conn,$sql2);
          echo mysqli_error($conn); 
    }

 function listing($conn){
    $stuinfo = mysqli_query($conn, "SELECT concat(P.firstname, ' ', P.lastname) as 'Full Name',S.SID, P.DOB, P.gender, P.nationality, P.address, 
    D.departmentName, D.Headofdepartment, C.Coursename, Bhouse.housename
    from Person as P Inner Join Students as S on P.Person_id=S.SID
    Inner Join Department as D on D.deptnum=P.deptnum
    Inner Join Courses as C on C.Course_id=S.CourseID
    Inner Join BoardingHouse as Bhouse on Bhouse.houseID=S.HouseNo
    Order by P.lastname asc");
    $data=mysqli_fetch_all($stuinfo,MYSQLI_ASSOC);
    echo mysqli_error($conn);
    return $data;
}
 $data=(listing($conn));


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="../css/styles.css">
    <title>GADE CENTRAL SCHOOL</title>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
          <a class="navbar-brand " href="index.php"><img src="../images/logo.png" width="95.3" height="71.3"></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse " id="navbarText">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0 bars" >
              <form action="" method="get">
                  <li>          
                      <input type="text" name= "searchbar"  placeholder="Search..">           
                  </li>
              </form>
              <li class="nav-item">
                <a class="nav-link active barsbars" aria-current="page" href="index.php">Home</a>
              </li>
              <li class="nav-item ">
                <a class="nav-link active barsbars" href="fees.php">Fees</a>
              </li>
              <li class="nav-item ">
                <a class="nav-link active barsbars" href="boarding.php">Boarding Info</a>
              </li>
              <li class="nav-item ">
                <a class="nav-link active barsbars" href="attendance.php">Student Attendance</a>
              </li>
              <li class="nav-item ">
                <a class="nav-link active barsbars" href="../forms/student_form.php">New Entry</a>
              </li>
            </ul>
        </div>
        </div>
      </nav>
      <table class="table table-sm">
      <tr>
            <th>Fullname</th>
            <th>DOB</th>
            <th>Gender</th>
            <th>Nationality</th>
            <th>Address</th>
            <th>Department Name</th>
            <th>Head of Department</th>
            <th>Course</th>
            <th>House Name</th>
        </tr>

        <?php foreach($data as $q) { ?> 
            <tr>
                <?php if (in_array($q['Full Name'],$searchresult)) { ?>
                    <td class="highlight"><?php echo $q['Full Name'] ?></td>
                <?php } else { ?>
                    <td><?php echo $q['Full Name'] ?></td>
                <?php } ?>
                <td><?php echo $q['Full Name'] ?></td>
                <td><?php echo $q['DOB'] ?></td>
                <td><?php echo $q['gender'] ?></td>
                <td><?php echo $q['nationality'] ?></td>
                <td><?php echo $q['address'] ?></td>
                <td><?php echo $q['departmentName'] ?></td>
                <td><?php echo $q['Headofdepartment'] ?></td>
                <td><?php echo $q['Coursename'] ?></td>
                <td><?php echo $q['housename'] ?></td>
                <td>
                    <form action="" method="post">
                        <input class="btn btn-danger" type = "submit" name="Delete"  value="Delete"/>
                        <input type="text" name="ID" value="<?php echo $q["SID"] ?>" hidden/>  
                    </form>
                </td>
            </tr>
        <?php } ?>

    </table>
</html>