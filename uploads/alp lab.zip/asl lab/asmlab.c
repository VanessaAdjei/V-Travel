#include "MKL25Z4.H"
extern int add10(void);
extern int stacklargest(int a, int b, int c, int d, int e, int f);
extern int anotherfunction(int a, int b, int c, int d, int e, int f);
extern int function(void);
extern int F();




int main(){

   function();


}
